"use strict"

// Callback Numbers

let callbackNumbers = document.querySelector('.about-content__information-list').getElementsByTagName('li');

for(let i = 0; i < callbackNumbers.length; i++) {
    callbackNumbers[i].innerHTML = callbackNumbers[i].textContent.replace(/([0-9.]+)/g, '<span>$1</span>');
}

// Menu Toggle

let menuToggle = document.querySelector('.menu-toggle');
let menuNavList = document.querySelector('.nav-menu__list');

function toggleMenu() {
    menuToggle.classList.toggle('menu-toggle_active');
    menuNavList.classList.toggle('nav-menu__list_active');
}

menuToggle.addEventListener('click', function() {
    toggleMenu()
})

function closseMenu() {
    menuToggle.classList.remove('menu-toggle_active');
    menuNavList.classList.remove('nav-menu__list_active');
}
document.addEventListener('click', function(e) {
    if(e.target) {
        return menuNavList.closest('.nav-menu__container')
    } else {
        closseMenu();
    }
})

// Section General About Window

const aboutLinks = document.querySelectorAll('.menu-link');
const body = document.querySelector('body');
const lockPadding = document.querySelectorAll('.lock-padding');

let unlock = true;
const timeout = 800;

if(aboutLinks.length > 0) {
    for(let index = 0; index < aboutLinks.length; index++) {
        const aboutLink = aboutLinks[index];
        aboutLink.addEventListener('click', function(e) {
            const aboutName = aboutLink.getAttribute('href').replace('#', '');
            const curentAbout = document.getElementById(aboutName);
            aboutOpen(curentAbout);
            e.preventDefault();
        });
    }
}

const aboutCloseIcon = document.querySelectorAll('.button-closse');
if(aboutCloseIcon.length > 0) {
    for(let index = 0; index < aboutCloseIcon.length; index++) {
        const el = aboutCloseIcon[index];
        el.addEventListener('click', function(e) {
            aboutClose(el.closest('.about-section'));
            e.preventDefault();
        });
    }
}

function aboutOpen(curentAbout) {
    if(curentAbout && unlock) {
        const aboutActive = document.querySelector('.about-section.open');
        if(aboutActive) {
            aboutClose(aboutActive, false);
        } else {
            bodyLock();
        }
        curentAbout.classList.add('open');
        curentAbout.addEventListener('click', function(e) {
            if(!e.target.closest('.about-content')) {
                aboutClose(e.target.closest('.about-section'));
            }
        });
    }
}
function aboutClose(aboutActive, doUnLock = true) {
    if(unlock) {
        aboutActive.classList.remove('open');
        if(doUnLock) {
            bodyUnLock();
        }
    }
}

function bodyLock() {
    const lockPaddingValue = window.innerWidth - document.querySelector('#header-section').offsetWidth + 'px';

    if(lockPadding.length > 0) {
        for(let index = 0; index < lockPadding.length; index++) {
            const el = lockPadding[index];
            el.style.paddingRight = lockPaddingValue;
        }
    }
    body.style.paddingRight = lockPaddingValue;
    body.classList.add('lock');

    unlock = false;
    setTimeout(function() {
        unlock = true;
    }, timeout);
}

function bodyUnLock() {
    setTimeout(function() {
        if(lockPadding.length > 0) {
            for(let index = 0; index < lockPadding.length; index++) {
                const el = lockPadding[index];
                el.style.paddingRight = '0px';
            }
        }
        body.style.paddingRight = '0px';
        body.classList.remove('lock');
    }, timeout);

    unlock = false;
    setTimeout(function() {
        unlock = true;
    }, timeout);
}

document.addEventListener('keydown', function(e) {
    if(e.which === 27) {
        const aboutActive = document.querySelector('.about-section.open');
        aboutClose(aboutActive);
    }
});

(function() {
    if(!Element.prototype.closest) {
        Element.prototype.closest = function(css) {
            let node = this;
            while(node) {
                if(node.matches(css)) return node;
                else node = node.parentElement;
            }
            return null;
        };
    }
})();
(function() {
    if(!Element.prototype.matches) {
        Element.prototype.matches = Element.prototype.matchesSelector ||
        Element.prototype.webkitMatchesSelector ||
        Element.prototype.mozMatches.Selector ||
        Element.prototype.msMatchesSelector;
    }
})();

// Form Section Estimation

// const ratings = document.querySelectorAll('.estimation-rating');

// if(ratings.length > 0) {
//     initRatings();.
// }

// function initRatings() {
//     let ratingActive, ratingValue;
//     // Перебираем весь рейтинг на странице
//     for(let index = 0; index < ratings.length; index++) {
//         const rating = ratings[index];
//         initRating(rating);
//     }

//     //Инициализируем конкретный рейтинг
//     function initRating(rating) {
//         initRatingVars(rating);
//         setRatingActiveWidth();

//         if(rating.classList.contains('estimation-rating__set')) {
//             setRating(rating);
//         }
//     }

//     //Инициализация переменных
//     function initRatingVars(rating) {
//         ratingActive = rating.querySelector('.estimation-rating__active');
//         ratingValue = rating.querySelector('.estimation-rating__value');
//     }

//     //Изменяем ширину активных звезд
//     function setRatingActiveWidth(index = ratingValue.innerHTML) {
//         const ratingActiveWidth = index / 0.05;
//         ratingActive.style.width = `${ratingActiveWidth}%`;
//     }

//     //Возможность указывать оценку
//     function setRating(rating) {
//         const ratingItems = rating.querySelectorAll('.estimation-rating__item');
//         for(let index = 0; index < ratingItems.length; index++) {
//             const ratingItem = ratingItems[index];
//             ratingItem.addEventListener('mouseenter', function(e) {
//                 //Обновление переменных
//                 initRatingVars(rating);
//                 //Обновление активных звезд
//                 setRatingActiveWidth(ratingItem.value);
//             });
//             ratingItem.addEventListener('mouseleave', function(e) {
//                 //Обновление активных звезд
//                 setRatingActiveWidth();
//             });
//             ratingItem.addEventListener('click', function(e) {
//                 //Обновление переменных
//                 initRatingVars(rating);

//                 if(rating.dataset.ajax) {
//                     setRatingValue(ratingItem.value, rating);
//                 } else {
//                     //Отобразить указанную оценку
//                     ratingValue.innerHTML = index + 1;
//                     setRatingActiveWidth();
//                 }
//             });
//         }
//     }

//     async function setRatingValue(value, rating) {
//         if(!rating.classList.contains('estimation-rating__sending')) {
//             rating.classList.add('estimation-rating__sending');

//             //Отправка данных на сервер
//             let response = await fetch('rating.json', {
//                 method: 'GET',
//                 // body: JSON.stringify({
//                 //     userRating: value
//                 // }),
//                 // headers: {
//                 //     'content-type': 'application/json'
//                 // }
//             });
//             if(response.ok) {
//                 const result = await response.json();

//                 //Получаем новый рейтинг
//                 const newRating = result.newRating;

//                 //Вывод нового среднего результата
//                 ratingValue.innerHTML = newRating;

//                 //Обновление активных звезд
//                 setRatingActiveWidth();

//                 rating.classList.remove('estimation-rating__sending');
//             } else {
//                 alert('Ошибка');
//                 rating.classList.remove('estimation-rating__sending');
//             }
//         }
//     }
// }

//Form Section Contacts

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('form-contacts');
    form.addEventListener('submit', formSend);

    async function formSend(e) {
        e.preventDefault();
        let error = formValidate(form);
        let formData = new FormData(form);

        if(error === 0) {
            form.classList.add('_sending');
            let response = await fetch('sendmail.php', {
                method: 'POST',
                body: formData
            });
            if(response.ok) {
                let result = await response.json();
                alert(result.message);
                formPreview.innerHTML = '';
                form.reset();
                form.classList.remove('_sending');
            } else {
                let eventsError = document.querySelector('.contacts-form__events-error');
                eventsError.style.display = 'block';
                form.classList.remove('_sending');

                form.addEventListener('click', function() {
                    eventsError.style.display = 'none';
                })
            }
        } else {
            let eventsFill = document.querySelector('.contacts-form__events-fill');
            eventsFill.style.display = 'block';

            form.addEventListener('click', function() {
                eventsFill.style.display = 'none';
            })
        }
    }

    function formValidate(form) {
        let error = 0;
        let formReq = document.querySelectorAll('._req');

        for(let index = 0; index < formReq.length; index++) {
            const input = formReq[index];
            formRemoveError(input);

            if(input.classList.contains('_email')) {
                if(emailTest(input)) {
                    formAddError(input);
                    error++;
                }
            } else {
                if(input.value === '') {
                    formAddError(input);
                    error++;
                }
            }
        }
        return error;
    }

    function formAddError(input) {
        input.parentElement.classList.add('_error');
        input.classList.add('_error');
    }

    function formRemoveError(input) {
        input.parentElement.classList.remove('_error');
        input.classList.remove('_error');
    }

    //Функция проверки e-mail

    function emailTest(input) {
        return !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,8})+$/.test(input.value);
    }
})